<x-mail::message>
{{ $message }}

Name: <b>{{ $name }}</b><br>
Email: <b>{{ $email }}</b><br>
Phone: <b>{{ $phone }}</b><br>
Service: <b>{{ $service }}</b><br>
</x-mail::message>
